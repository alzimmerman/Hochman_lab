
axes(handles.axes1);
cla;
set(gca,'XTickLabel','');
set(gca,'YTickLabel','');
xlabel('','FontSize',11);
ylabel('','FontSize',11);
title('');