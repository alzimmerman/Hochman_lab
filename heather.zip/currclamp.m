%function inputs current clamp data and exports average firing properties and passive properties for
%current clamp protocols

function [VTH,AMP,DUR,DUR2,AHPMAG,AHPDUR,FREQ,k,current,VM_SS,VM_BASE,TAU,first_spike,temp]=currclamp(file,injection)

time=(file.data.time');
Vm= file.data.c_clamp./10;
Iwaveform=file.waveform.yPoints+injection;
Swaveform=file.waveform.xPoints;  %gives sample number

[R,C]=size(Vm);
Fs=1/time(2);

AMP=zeros(1,C); 
DUR=zeros(1,C);
DUR2=zeros(1,C);
AHPDUR=zeros(1,C); 
AHPMAG= zeros(1,C);
VTH=zeros(1,C);
FREQ=zeros(1,C);
current=zeros(1,C);
VM_SS=zeros(1,C);
VM_BASE=zeros(1,C);
TAU=zeros(1,C);
first_spike=zeros(1,C);
temp={};
%for initial calculation of clamp times
j=find(Iwaveform(:,1)~=injection,1);
clampon=Swaveform(j,1);
clampoff=Swaveform(j+1,1);

for i=1:C
    current(i)=Iwaveform(j,i);
    
    [Vm_ss,Vm_base,tau]=find_tau(time,Vm(:,i),clampon,clampoff,R,current(i),injection);
    TAU(i)=tau;
    VM_SS(i)=Vm_ss;
    VM_BASE(i)=Vm_base;
    delta=Vm_ss-Vm_base;
    
%     s = fitoptions('Method','NonlinearLeastSquares',...
%                'Lower',[0,0],...
%                'Upper',[max(time),max(time)],...
%                'Startpoint',[.01 .01]);
%     f=fittype('delta*(exp(-x/tau1)+exp(-x/tau2))','problem','delta','options',s);
%     [temp,gof]=fit((time-time(clampon)),(Vm(:,i)-Vm_base),'exp2','Startpoint',[0.01 1 0.01 1])
% %     temp=(exp(-1)*(Vm_ss-Vm_base))+Vm_base;
    %figure(1); plot(time(clampoff:R),Vm(clampoff:R,i),'-',time(clampoff:R),temp2(clampoff:R),'--'); hold all
    [amp,peak,dur,dur2,AHPdur,AHPmag,Vth,spikes2]=spikeparams(time,Vm(:,i),clampon,clampoff);
    [mean_amp,mean_dur,mean_AHPdur,mean_AHPmag,mean_Vth,mean_freq,frequency_full,first_params]= meanparameters(amp,peak,dur,dur2,AHPdur,AHPmag,Vth,spikes2,Fs);

 %figure(6); plot(time,Vm(:,i),'-',time(spikes2),Vth,'^'); hold all
   if isempty(spikes2)<1
       first_spike(i)=time(spikes2(1))-time(clampon);
   end
   
   %adds current value of parameters to parameter vectors
    AMP(i)=mean_amp;
    DUR(i)=mean_dur;
    AHPDUR(i)= mean_AHPdur;
    AHPMAG(i)= mean_AHPmag;
    VTH(i)=mean_Vth;  
    FREQ(i)=mean_freq;
    temp(i).frequency=frequency_full;
    temp(i).firstparams=first_params;
    temp(i).Vth=Vth; temp(i).amp=amp; temp(i).dur=dur; temp(i).AHPmag=AHPmag; temp(i).AHPdur=AHPdur;
   

end

%only plots nonzero values for active properties
for i=1:length(current)
    k=find(FREQ~=0);
end


end
    